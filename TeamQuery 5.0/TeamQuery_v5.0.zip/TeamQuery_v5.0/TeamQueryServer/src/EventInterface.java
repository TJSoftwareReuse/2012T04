

public interface EventInterface {
	public void btnReload_Click();
}
