
public interface EventInterface {
	public boolean queryByName(String strStudentName);
	public boolean queryById(int nStudentId);
	public boolean queryByTeamId(int nTeamId);
}
